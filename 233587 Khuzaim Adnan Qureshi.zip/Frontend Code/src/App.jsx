import { useState , useEffect } from 'react'
import BookPage from './pages/BookPage'
import './App.css'

function App() {
  return (
    <>
      <BookPage />
    </>
  )
}

export default App
